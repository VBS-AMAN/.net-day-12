using Demo_EntityFramewoek_CodeFirst.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo_EntityFramewoek_CodeFirst
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
            using (var contxt = new RecordContext())
            {
               var student1 = new Student() { Name = "yadav" , Course ="CS", Contact="Delhi", Email="yadav@gamil.com", Id = 01 }; // adding an object using contxt 
               // contxt.Students.Add(student1);
                contxt.SaveChanges();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
