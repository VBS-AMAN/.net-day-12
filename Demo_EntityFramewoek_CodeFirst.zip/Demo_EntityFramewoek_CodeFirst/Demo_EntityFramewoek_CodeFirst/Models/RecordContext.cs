﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Demo_EntityFramewoek_CodeFirst;
using System.Data;

namespace Demo_EntityFramewoek_CodeFirst.Models
{
    public class RecordContext : DbContext
    {
        ///constructor
        public RecordContext():base()
        {
            
        }
        public DbSet<Student> Aman_student { get; set; }
        //no of tables we want to create in db
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=192.168.1.230;Initial Catalog= AdventureWorks2017;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022");
        }

    }
}
