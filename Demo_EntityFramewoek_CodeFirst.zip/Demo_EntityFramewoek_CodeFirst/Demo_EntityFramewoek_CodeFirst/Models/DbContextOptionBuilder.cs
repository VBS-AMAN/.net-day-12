﻿namespace Demo_EntityFramewoek_CodeFirst.Models
{
    public class DbContextOptionBuilder
    {
    }
}